function newFood(img,v,n,d,p){
    this.image = img;
    this.cat = v;
    this.name = n;
    this.detail = d;
    this.price = p;
}
function trendFood(img,v,n,d,p){
    this.image = img;
    this.cat = v;
    this.name = n;
    this.detail = d;
    this.price = p;
}
function timeFood(img,v,n,d,p){
    this.image = img;
    this.cat = v;
    this.name = n;
    this.detail = d;
    this.price = p;
}


let newfood = [];
let trendfood = [];
let timefood = [];


let Newfood1 = new newFood ("https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/f_auto,q_auto,w_250/v1648698127/Item/5276D.png",
                            "https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/v1591261933/NewWebsiteResource2020/Assets/Img/Veg.svg",
                            "Triple Cheese American Veg Burger",
                            "A crunchy Corn patty filled with Cheese, topped with Jalapenos, shredded Lettuce and more cheese, layered between the goodness of whole wheat buns.",
                            "195"
)
let Newfood2 = new newFood ("https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/f_auto,q_auto,w_250/v1626242155/Item/5294.png",
                            "https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/v1591261933/NewWebsiteResource2020/Assets/Img/Veg.svg",
                            "McSpicy Premium Veg Burger",
                            "A spicy Paneer patty, shredded Lettuce topped with Jalapenos and Cheese slice, Spicy Cocktail sauce & Cheese sauce layered between toasted Whole Wheat Buns.",
                            "210",
)
let Newfood3 = new newFood ("https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/f_auto,q_auto,w_250/v1648698126/Item/5275D.png",
                            "https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/v1591261933/NewWebsiteResource2020/Assets/Img/nonveg.svg",
                            "Triple Cheese American Chicken Burger",
                            "A flame-grilled Chicken patty filled with Cheese, topped with Jalapenos, shredded Lettuce and more Cheese, layered between the goodness of whole wheat buns.",
                            "220",
)
let Newfood4 = new newFood ("https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/f_auto,q_auto,w_250/v1626242194/Item/5293.png",
                              "https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/v1591261933/NewWebsiteResource2020/Assets/Img/nonveg.svg",
                              "McSpicy Premium Chicken Burger",
                              "A spicy Chicken patty, shredded Lettuce topped with Jalapenos and Cheese slice, Spicy Habanero sauce & Cheese sauce layered between toasted Whole Wheat Buns.",
                              "249",
)
let trendfood1 = new trendFood ("https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/f_auto,q_auto,w_250/v1648624946/Item/65D.png",
                                "https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/v1591261933/NewWebsiteResource2020/Assets/Img/veg.svg",
                                "McAloo Tikki Burger",
                                "The World's favourite Indian burger! Crunchy potato and peas patty with delicious Tom Mayo & crunchy onions; now with Whole Wheat Bun",
                                "49",
)
let trendfood2 = new trendFood ("https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/f_auto,q_auto,w_250/v1642087175/Item/47.png",
                                "https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/v1591261933/NewWebsiteResource2020/Assets/Img/nonveg.svg",
                                "McSpicy Chicken Burger",
                                "Tender and juicy chicken patty coated in spicy, crispy batter topped with a creamy sauce and crispy shredded lettuce will have you craving for more.",
                                "165",
)
let trendfood3 = new trendFood ("https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/f_auto,q_auto,w_250/v1589466276/Item/40.png",
                                "https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/v1591261933/NewWebsiteResource2020/Assets/Img/Veg.svg",
                                "McVeggie Burger",
                                "An everyday classic burger with a delectable patty filled with potatoes, carrots and tasty Indian spices; topped with crunchy lettuce and mayonaise.",
                                "115",
)
let trendfood4 = new trendFood ("https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/f_auto,q_auto,w_250/v1589466276/Item/40.png",
                               "https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/v1591261933/NewWebsiteResource2020/Assets/Img/nonveg.svg",
                               "McChicken Burger",
                               "Tender and juicy chicken patty cooked to perfection, with creamy mayonnaise and crunchy lettuce adding flavour to each bite.",
                               "120",
)
let timefood1 = new timeFood ("https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/f_auto,q_auto,w_250/v1648698131/Item/6227D.png",
                               "https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/v1591261933/NewWebsiteResource2020/Assets/Img/Veg.svg",
                               "Classic Burger Meals",
                               "Make your own classic favourite meal with a choice of 2 burgers; Large Fries and 2 Coke",
                               "457",
)
let timefood2 = new timeFood ("https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/f_auto,q_auto,w_250/v1648534883/Item/6176D.png",
                              "https://images.mcdelivery.co.in/hardcastle-restaurants-pvt-ltd/image/upload/v1591261933/NewWebsiteResource2020/Assets/Img/Veg.svg",
                              "Indulgent Burger Meals",
                              "Make your own Gourmet favourite meal with a choice of 2 burgers; Large Fries and 2 Coke",
                              "590",
)
let food = [];

newfood.push(Newfood1,Newfood2,Newfood3,Newfood4);
trendfood.push(trendfood1,trendfood2,trendfood3,trendfood4);
timefood.push(timefood1,timefood2);

food.push(newfood,trendfood,timefood);

localStorage.setItem("foodData",JSON.stringify(food))

const data = JSON.parse(localStorage.getItem("foodData"))

// let x = document.getElementById("food")
// console.log(x)

let a = 1;

let id = 0;
    
for(let i=0;i<data.length;i++){
    let foodItems = document.getElementById(`foodlist${a++}`)
    // console.log(foodItems)
    let data1 = data[i]
    data1.map(function(elem){
        let input = document.createElement("input")
        input.type = "checkbox"
        input.id = `item${id++}`
        input.value = "yes"
        // console.log(`item${id}`)
        let label = document.createElement("label")
        label.htmlFor = "box"

        let img1 = document.createElement("img")
        img1.src = elem.image
        img1.id = "item"

        let img2 = document.createElement("img")
        img2.src = elem.cat
        img2.id = "cat"

        let name = document.createElement("h2")
        name.innerText = elem.name

        let detail = document.createElement("p")
        detail.innerText = elem.detail
        detail.className = "details"

        let price = document.createElement("p")
        price.innerText = `₹${elem.price}`

        let box = document.createElement("div")
        box.id = "de"

        box.append(img2,name,price,detail)

        label.append(img1,box)

        foodItems.append(input,label)
    })
    let submit = document.createElement("input")
    submit.type = "submit"
    submit.id = "submit"
    foodItems.append(submit)


}

let order = document.getElementById(`order`)

function placeOrder(){

event.preventDefault()  

order.innerHTML = `Please Wait`
let time = Math.random() * 3 * 1000;
setTimeout(function(){
    order.innerHTML = ``
    let i = 0;
    let arr = [];
    // console.log(data)
    while(i<data.length){
        let c = 0;
        for(let j=0;j<data[i].length;j++){
            let check = document.getElementById(`item${c++}`)
            // console.log("ids",`item${c}`)
            if(check.checked == true){
                arr.push(c)           
                console.log("arr",arr.push(c))     
            }
        }        
        i++
    }
    for(let q=0;q<arr.length-i+1;q++){
        // console.log(arr[q])  
        let img1 = document.createElement("img")
        // img1.src = data[i][q].image
        console.log(data[q])
        let img2 = document.createElement("img")
        // img2.src = data[i].cat

        let name = document.createElement("h2")
        // name.innerText = data[i].name

        order.append(img1,img2,name)
    }
},time)
}


let new1 = document.getElementById(`foodlist1`)
let trend = document.getElementById(`foodlist2`)
let time = document.getElementById(`foodlist3`)
let h1 = document.getElementById("h1")

function dis1(){
    trend.style.display = "none"
    new1.style.display = "grid"
    time.style.display = "none"
    h1.innerText = "New Launches"
}

function dis2(){
    trend.style.display = "grid"
    new1.style.display = "none"
    time.style.display = "none"
    h1.innerText = "Trending"
}

function dis3(){
    trend.style.display = "none"
    new1.style.display = "none"
    time.style.display = "grid"
    h1.innerText = "Match Time Meals"
}